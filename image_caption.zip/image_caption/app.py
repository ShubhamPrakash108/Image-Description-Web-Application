# app.py
from flask import Flask, render_template, request, jsonify
import requests
from PIL import Image
from io import BytesIO
import os

app = Flask(__name__)

# Configure upload folder
UPLOAD_FOLDER = 'static/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# API endpoint
API_URL = 'https://0407-35-247-104-50.ngrok-free.app/generate-caption/'

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'jfif'}

@app.route('/', methods=['GET'])
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    if file and allowed_file(file.filename):
        try:
            # Read and process the image
            img = Image.open(file.stream)
            img = img.convert('RGB')
            
            # Save image to BytesIO object
            buffered = BytesIO()
            img.save(buffered, format='JPEG')
            image_bytes = buffered.getvalue()
            
            # Save file for display
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            img.save(filename)
            
            # Prepare file for API
            files = {
                "file": (file.filename, image_bytes, "image/jpeg")
            }
            
            # Make request to API
            response = requests.post(API_URL, files=files)
            response.raise_for_status()
            
            result = response.json()
            
            return jsonify({
                'success': True,
                'caption': result.get('caption', 'No caption generated'),
                'image_path': os.path.join('uploads', file.filename)
            })
            
        except requests.exceptions.RequestException as e:
            return jsonify({'error': f'API Error: {str(e)}'}), 500
        except Exception as e:
            return jsonify({'error': f'Processing Error: {str(e)}'}), 500
            
    return jsonify({'error': 'Invalid file type'}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)